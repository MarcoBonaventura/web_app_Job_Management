# Angular 11, Web API, SQL Server App project
<ul>
<li>front-end with Angular 11, Materials for web animation + Bootstrap</li>
<li>back-end webapi C# + MS SQL Stored Procedures</li>
